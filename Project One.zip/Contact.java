
public class Contact {
	
	private static final int CONTACT_PHONENUM_LENGTH = 10;
	 private static final byte CONTACT_ID_LENGTH = 10;
	 private static final byte CONTACT_FNAME_LENGTH = 10;
	 private static final byte CONTACT_LNAME_LENGTH = 10;
	 private static final byte CONTACT_ADDRESS_LENGTH = 30;
	 private static final String INITIALIZER = "INITIAL";
	 private static final String INITIALIZER_NUM = "1235559999";
	 private String contactId;
	 private String firstName;
	 private String lastName;
	 private String phoneNumber;
	 private String address;
	 
	 Contact() {
		 
	 this.contactId = INITIALIZER;
	 this.firstName = INITIALIZER;
	 this.lastName = INITIALIZER;
	 this.phoneNumber = INITIALIZER_NUM;
	 this.address = INITIALIZER;
	 
	 }
	 Contact(String contactId) {
		 
	 updateContactId(contactId);
	 this.firstName = INITIALIZER;
	 this.lastName = INITIALIZER;
	 this.phoneNumber = INITIALIZER_NUM;
	 this.address = INITIALIZER;
	 
	 }
	 Contact(String contactId, String firstName) {
		 
	 updateContactId(contactId);
	 updateFirstName(firstName);
	 this.lastName = INITIALIZER;
	 this.phoneNumber = INITIALIZER_NUM;
	 this.address = INITIALIZER;
	 
	 }
	 
	 Contact(String contactId, String firstName, String lastName) {
		 
	 updateContactId(contactId);
	 updateFirstName(firstName);
	 updateLastName(lastName);
	 this.phoneNumber = INITIALIZER_NUM;
	 this.address = INITIALIZER;
	 
	 }
	 Contact(String contactId, String firstName, String lastName, String phoneNumber) {
		 
	 updateContactId(contactId);
	 updateFirstName(firstName);
	 updateLastName(lastName);
	 updatePhoneNumber(phoneNumber);
	 this.address = INITIALIZER;
	 
	 }
	 Contact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
		 
	 updateContactId(contactId);
	 updateFirstName(firstName);
	 updateLastName(lastName);
	 updatePhoneNumber(phoneNumber);
	 updateAddress(address);
	 
	 }


}
