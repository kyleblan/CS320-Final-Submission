package Test;

import java.util.*;

public class Appointment {

	private String appointmentId; //length 10
	 private Date appointmentDate; //appointmentDate >= currentDate
	 private String description; //length 50

	 Appointment(String aid, Date d, String descript) {
	Date today = new Date();

	//checks id
	if(aid == null || aid.length() > 10) {
	 throw new IllegalArgumentException("Invalid appointment id - null or length > 10");
	 }
	//checks date
	if(d == null) {
	throw new IllegalArgumentException("Invalid appointment date - null");
	}
	else if(d.before(today)) {
	throw new IllegalArgumentException("Invalid appointment date - past date");
	}

	//checks description
	if(descript == null || descript.length() > 50) {
	throw new IllegalArgumentException("Invalid description - null or length > 50");
	}
	this.appointmentId = aid;
	this.appointmentDate = d;
	this.description = descript;

	 }

	 //getters
	 public String getAppointmentID() {return appointmentId;}
	 public Date getAppointmentDate() {return appointmentDate;}
	 public String getDescription() {return description;}

	 //setters
	 public void setAppointmentID(String aid) {
	 if(aid == null || aid.length() > 10) {
	 throw new IllegalArgumentException("Invalid appointment id - null or length > 10");
	 }
	 else {this.appointmentId = aid;}
	 }

	 public void setAppointmentDate(Date d) {

	 Date today = new Date();
	 
	 if(d == null) {
		 throw new IllegalArgumentException("Invalid appointment date - null");
		 }
		 else if(d.before(today)) {
		 throw new IllegalArgumentException("Invalid appointment date - past date");
		 }
		 else {this.appointmentDate = d;}
		  }

		  public void setDescription(String descript) {
		  if(descript == null || descript.length() > 50) {
		 throw new IllegalArgumentException("Invalid description - null or length > 50");
		 }
		  else {this.description = descript;}
		  }
}
